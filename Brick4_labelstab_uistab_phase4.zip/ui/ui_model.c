/**
 * @file ui_model.c
 * @brief État interne mutable de l’UI Brick (copie en RAM des valeurs de la cartouche).
 *
 * @ingroup ui
 *
 * Gère la structure d’état en mémoire pour la partie interface utilisateur.
 * Le modèle sépare les valeurs volatiles (en RAM) de la définition immuable
 * des paramètres (`ui_spec`), afin de permettre :
 * - Une réinitialisation facile des valeurs par défaut
 * - Une édition UI sans altérer les définitions de la cartouche
 */

#include "ui_model.h"
#include <string.h>

/**
 * @brief Initialise un état UI à partir d’une spécification de cartouche.
 *
 * Copie les valeurs par défaut définies dans la spec (`default_value`)
 * vers la structure RAM `ui_state_t`.
 * Les paramètres sans label (non présents sur la page) sont initialisés à zéro.
 *
 * @param st   Pointeur vers l’état à initialiser (RAM).
 * @param spec Spécification de la cartouche (immuable).
 */
void ui_state_init(ui_state_t *st, const ui_cart_spec_t *spec) {
    st->spec     = spec;
    st->cur_menu = 0;
    st->cur_page = 0;
    st->shift    = false;

    if (!spec) {
        memset(&st->vals, 0, sizeof(st->vals));
        return;
    }

    // Copier les valeurs par défaut dans l’état
    for (int m = 0; m < UI_MAX_MENUS; m++) {
        for (int p = 0; p < UI_MAX_PAGES; p++) {
            for (int i = 0; i < UI_PARAMS_PER_PAGE; i++) {
                const ui_param_spec_t *ps = &spec->menus[m].pages[p].params[i];
                ui_param_state_t      *pv = &st->vals.menus[m].pages[p].params[i];

                // Si pas de label → paramètre absent, valeur 0 par défaut
                pv->value = ps->label ? ps->default_value : 0;
            }
        }
    }
}
