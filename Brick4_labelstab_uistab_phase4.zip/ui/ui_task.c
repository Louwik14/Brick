/**
 * @file ui_task.c
 * @brief Thread principal de l’interface utilisateur Brick.
 *
 * Ce module orchestre la boucle de lecture des entrées (boutons, encodeurs),
 * applique les actions sur l’UI via `ui_controller`, et déclenche le rendu
 * conditionnel à l’écran via `ui_renderer`.
 *
 * @ingroup ui
 *
 * Responsibilities
 * - Poll des entrées (ui_input)
 * - Application des actions UI (ui_controller)
 * - Rafraîchissement conditionnel de l’écran (ui_renderer)
 * - Gestion du changement de cartouche via `cart_registry`
 *
 * Threading & Timing
 * - Thread dédié : priorité NORMALPRIO
 * - Polling : toutes les 20 ms
 * - Rendu : uniquement si “dirty” ou heartbeat (500 ms)
 *
 * Contracts
 * - Aucune I/O bloquante
 * - Événements marquent l’UI comme “dirty”
 * - Accès à l’écran uniquement via `drv_display`
 */

#include "ch.h"
#include "hal.h"

#include "ui_task.h"
#include "ui_input.h"
#include "ui_renderer.h"
#include "ui_controller.h"
#include "cart_registry.h"       // gestion cartouches (active, specs)

/* ============================================================
 * Configuration
 * ============================================================ */
#ifndef UI_TASK_STACK
#define UI_TASK_STACK 1024
#endif

#ifndef UI_TASK_PRIO
#define UI_TASK_PRIO  (NORMALPRIO)
#endif

static THD_WORKING_AREA(waUI, UI_TASK_STACK);
static thread_t* s_ui_thread = NULL;

/* ============================================================
 * Boucle principale du thread UI
 * ============================================================ */
static THD_FUNCTION(UIThread, arg) {
    (void)arg;
    chRegSetThreadName("UI");

    ui_input_event_t evt;

    systime_t last_heartbeat = chVTGetSystemTimeX();
    const systime_t heartbeat_interval = TIME_MS2I(500); // 2 Hz pour animations/clignotements

    while (true) {
        /* --- Lecture des entrées (20 ms) --- */
        if (ui_input_poll(&evt, TIME_MS2I(20))) {

            /* --- Gestion des boutons --- */
            if (evt.has_button && evt.btn_pressed) {

                /* SHIFT + BM1..BM4 → changement de cartouche */
                if (ui_input_shift_is_pressed()) {
                    const ui_cart_spec_t* spec = NULL;

                    if      (evt.btn_id == UI_BTN_PARAM1) spec = cart_registry_switch(CART1);
                    else if (evt.btn_id == UI_BTN_PARAM2) spec = cart_registry_switch(CART2);
                    else if (evt.btn_id == UI_BTN_PARAM3) spec = cart_registry_switch(CART3);
                    else if (evt.btn_id == UI_BTN_PARAM4) spec = cart_registry_switch(CART4);

                    if (spec) {
                        ui_switch_cart(spec);  // applique la nouvelle UI
                    }
                } else {
                    /* Menus (BM1..BM8) */
                    if      (evt.btn_id == UI_BTN_PARAM1) ui_on_button_menu(0);
                    else if (evt.btn_id == UI_BTN_PARAM2) ui_on_button_menu(1);
                    else if (evt.btn_id == UI_BTN_PARAM3) ui_on_button_menu(2);
                    else if (evt.btn_id == UI_BTN_PARAM4) ui_on_button_menu(3);
                    else if (evt.btn_id == UI_BTN_PARAM5) ui_on_button_menu(4);
                    else if (evt.btn_id == UI_BTN_PARAM6) ui_on_button_menu(5);
                    else if (evt.btn_id == UI_BTN_PARAM7) ui_on_button_menu(6);
                    else if (evt.btn_id == UI_BTN_PARAM8) ui_on_button_menu(7);

                    /* Pages (P1..P5) */
                    else if (evt.btn_id == UI_BTN_PAGE1) ui_on_button_page(0);
                    else if (evt.btn_id == UI_BTN_PAGE2) ui_on_button_page(1);
                    else if (evt.btn_id == UI_BTN_PAGE3) ui_on_button_page(2);
                    else if (evt.btn_id == UI_BTN_PAGE4) ui_on_button_page(3);
                    else if (evt.btn_id == UI_BTN_PAGE5) ui_on_button_page(4);
                }

                ui_mark_dirty();  // marquer l’UI pour redraw
            }

            /* --- ENCODEURS --- */
            if (evt.has_encoder && evt.enc_delta != 0) {
                ui_on_encoder(evt.encoder, evt.enc_delta);
                ui_mark_dirty();
            }
        }

        /* Le drain encodeurs est désormais géré dans ui_input_poll() */

        /* --- Rendu conditionnel --- */
        bool heartbeat = (chVTGetSystemTimeX() - last_heartbeat) >= heartbeat_interval;
        if (heartbeat) {
            last_heartbeat = chVTGetSystemTimeX();
        }

        if (ui_is_dirty() || heartbeat) {
            ui_draw_frame(ui_get_cart(), ui_get_state());
            ui_clear_dirty();
        }

        chThdSleepMilliseconds(16); // ~60 FPS
    }
}

/* ============================================================
 *  Lancement / état du thread UI
 * ============================================================ */

/**
 * @brief Lance le thread UI s’il n’est pas déjà actif.
 */
void ui_task_start(void) {
    if (!s_ui_thread) {
        s_ui_thread = chThdCreateStatic(waUI, sizeof(waUI),
                                        UI_TASK_PRIO, UIThread, NULL);
    }
}

/**
 * @brief Indique si le thread UI est en cours d’exécution.
 */
bool ui_task_is_running(void) {
    return s_ui_thread != NULL;
}
