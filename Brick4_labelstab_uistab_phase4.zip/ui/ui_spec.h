/**
 * @file ui_spec.h
 * @brief Spécifications UI des cartouches Brick (menus/pages/paramètres).
 *
 * @ingroup ui
 *
 * @details
 * Ce header décrit les structures **purement UI** utilisées pour :
 * - définir les menus, pages et paramètres affichés (OLED),
 * - typer chaque paramètre (booléen, enum, continu),
 * - fournir les métadonnées nécessaires au rendu et au pilotage (labels, plages, step).
 *
 * Points importants :
 * - L’ordre des champs de ::ui_param_spec_t est **aligné** sur les tables XVA1
 *   pour permettre des initialisations agrégées simples.
 * - Les bornes de plage (::ui_param_range_t) sont en **int16_t** afin d’éviter
 *   tout overflow (ex. max=255) et pour supporter des bornes négatives.
 * - Ces types ne contiennent **aucune logique I/O** et ne dépendent pas des
 *   couches Cart/Bus : ils sont **UI-only**.
 */

#ifndef BRICK_UI_UI_SPEC_H
#define BRICK_UI_UI_SPEC_H

#include <stdint.h>
#include <stdbool.h>
#include "ui_types.h"  /**< ui_param_kind_t, etc. */

/* -------------------------------------------------------------------------- */
/* Capacités par défaut (modifiable au besoin)                                */
/* -------------------------------------------------------------------------- */

/**
 * @def UI_PARAMS_PER_PAGE
 * @brief Nombre de paramètres par page UI (par défaut 4).
 */
#ifndef UI_PARAMS_PER_PAGE
#define UI_PARAMS_PER_PAGE 4
#endif

/**
 * @def UI_PAGES_PER_MENU
 * @brief Nombre de pages par menu UI (par défaut 5).
 */
#ifndef UI_PAGES_PER_MENU
#define UI_PAGES_PER_MENU 5
#endif

/**
 * @def UI_MENUS_PER_CART
 * @brief Nombre maximal de menus exposés par une cartouche (par défaut 16).
 */
#ifndef UI_MENUS_PER_CART
#define UI_MENUS_PER_CART 16
#endif

/* -------------------------------------------------------------------------- */
/* Méta-données de paramètres                                                 */
/* -------------------------------------------------------------------------- */

/**
 * @brief Plage d’un paramètre **continu** (CONT).
 *
 * @details
 * - `min` / `max` sont en **int16_t** pour supporter 0..255 et des bornes négatives.
 * - `step` est le pas appliqué à chaque “cran” d’encodeur (>= 1).
 */
typedef struct ui_param_range_t {
    int16_t min;   /**< Borne minimale (peut être négative). */
    int16_t max;   /**< Borne maximale (peut aller jusqu’à 255 sans overflow). */
    uint8_t step;  /**< Pas d’incrément/décrément pour l’encodeur. */
} ui_param_range_t;

/**
 * @brief Métadonnées d’un paramètre **énuméré** (ENUM).
 *
 * @details
 * - `labels` peut être NULL (valeurs numériques brutes).
 * - `count` est le nombre d’entrées dans l’énumération.
 *
 * @note L’ordre {labels, count} est celui attendu par les tables XVA1.
 */
typedef struct ui_param_enum_t {
    const char* const *labels;  /**< Tableau de libellés, ou NULL. */
    int                count;   /**< Nombre d’entrées de l’énumération. */
} ui_param_enum_t;

/**
 * @brief Union des métadonnées de paramètre (continu **ou** énuméré).
 */
typedef union ui_param_meta_t {
    ui_param_range_t range;  /**< Métadonnées pour un paramètre CONT. */
    ui_param_enum_t  en;     /**< Métadonnées pour un paramètre ENUM. */
} ui_param_meta_t;

/* -------------------------------------------------------------------------- */
/* Paramètre UI                                                               */
/* -------------------------------------------------------------------------- */

/**
 * @brief Spécification d’un paramètre UI.
 *
 * @details
 * Ordre des champs **important** (compatibilité initialisations XVA1) :
 * `label → kind → dest_id → default_value → meta → is_bitwise → bit_mask`.
 *
 * - `dest_id` : identifiant “cartouche” (utilisé côté bus/uart via ui_backend).
 * - `default_value` : valeur initiale côté UI/model.
 * - `is_bitwise`/`bit_mask` : support des paramètres empaquetés (bitfields).
 */
typedef struct ui_param_spec_t {
    const char*     label;         /**< Libellé à afficher sur l’OLED. */
    ui_param_kind_t kind;          /**< Genre logique (BOOL/ENUM/CONT). */
    uint16_t        dest_id;       /**< Identifiant cartouche (UART / link). */
    uint8_t         default_value; /**< Valeur par défaut côté UI/model. */
    ui_param_meta_t meta;          /**< Métadonnées (plage ou énumération). */
    bool            is_bitwise;    /**< true si ce paramètre est un bitfield. */
    uint8_t         bit_mask;      /**< Masque binaire si `is_bitwise` est true. */
} ui_param_spec_t;

/* -------------------------------------------------------------------------- */
/* Page UI                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * @brief Spécification d’une page UI (groupe de paramètres).
 *
 * @details
 * - `params` : tableau fixe de @ref UI_PARAMS_PER_PAGE paramètres.
 * - `header_label` : en-tête optionnel affiché sur la page (peut être NULL).
 */
typedef struct ui_page_spec_t {
    ui_param_spec_t params[UI_PARAMS_PER_PAGE];  /**< Paramètres de la page. */
    const char*     header_label;                /**< En-tête optionnel (peut être NULL). */
} ui_page_spec_t;

/* -------------------------------------------------------------------------- */
/* Menu UI                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * @brief Spécification d’un menu UI (ensemble de pages).
 *
 * @details
 * - `name` : nom court du menu (affichage).
 * - `page_titles` : titres individuels des pages (peuvent être NULL).
 * - `pages` : tableau fixe de @ref UI_PAGES_PER_MENU pages.
 */
typedef struct ui_menu_spec_t {
    const char*     name;                               /**< Nom du menu (OLED). */
    const char*     page_titles[UI_PAGES_PER_MENU];     /**< Titres de pages (optionnels). */
    ui_page_spec_t  pages[UI_PAGES_PER_MENU];           /**< Pages du menu. */
} ui_menu_spec_t;

/* -------------------------------------------------------------------------- */
/* Spécification UI de cartouche                                              */
/* -------------------------------------------------------------------------- */

/**
 * @brief Spécification UI complète d’une cartouche.
 *
 * @details
 * - `cart_name` : nom affiché dans la barre de titre / entête.
 * - `menus` : tableau fixe de @ref UI_MENUS_PER_CART menus.
 *
 * @note Cette structure est typiquement déclarée `const` dans `cart_xxx_spec.c`
 *       et enregistrée via `cart_registry_register()`.
 */
typedef struct ui_cart_spec_t {
    const char*     cart_name;                          /**< Nom affiché. */
    ui_menu_spec_t  menus[UI_MENUS_PER_CART];           /**< Menus exposés par la cartouche. */
} ui_cart_spec_t;

#endif /* BRICK_UI_UI_SPEC_H */
