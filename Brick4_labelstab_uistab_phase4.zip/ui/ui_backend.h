/**
 * @file ui_backend.h
 * @brief Pont neutre entre la couche UI et la couche CartLink.
 *
 * @defgroup ui_backend UI Backend Bridge
 * @ingroup ui
 *
 * @details
 * Cette interface agit comme un adaptateur : elle permet à la couche UI
 * (controller, renderer, widgets) d’interagir avec le système de cartouches
 * sans dépendre directement de `cart_link`.
 *
 * @note Toutes les fonctions sont non bloquantes et appelées depuis le thread UI.
 */

#ifndef BRICK_UI_UI_BACKEND_H
#define BRICK_UI_UI_BACKEND_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Notifie un changement de paramètre issu de l’UI.
 * @ingroup ui_backend
 *
 * @param id        Identifiant de paramètre (dest_id côté cartouche)
 * @param val       Nouvelle valeur (0/1 ou 0–255)
 * @param bitwise   Si true, appliquer un masque binaire
 * @param mask      Masque de bits à appliquer lorsque @p bitwise est true
 */
void ui_backend_param_changed(uint16_t id, uint8_t val, bool bitwise, uint8_t mask);

/**
 * @brief Lecture du shadow register local (valeur courante affichable).
 * @ingroup ui_backend
 *
 * @param id Identifiant de paramètre
 * @return Valeur locale en cache pour ce paramètre.
 *
 * @note Aucune I/O cartouche n’est effectuée.
 */
uint8_t ui_backend_shadow_get(uint16_t id);

/**
 * @brief Écriture dans le shadow register local (sans envoi immédiat).
 * @ingroup ui_backend
 *
 * @param id  Identifiant de paramètre
 * @param val Valeur à stocker localement
 *
 * @note Permet de maintenir l’UI cohérente lors de manipulations bitfield.
 */
void ui_backend_shadow_set(uint16_t id, uint8_t val);

#ifdef __cplusplus
}
#endif

#endif /* BRICK_UI_UI_BACKEND_H */
