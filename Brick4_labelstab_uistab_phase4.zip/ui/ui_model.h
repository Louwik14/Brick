/**
 * @file ui_model.h
 * @brief Définition de l’état mutable de l’interface utilisateur Brick.
 *
 * @ingroup ui
 *
 * Le modèle UI (`ui_model`) conserve une copie RAM de toutes les valeurs
 * des paramètres d’une cartouche.
 * Il est initialisé à partir d’une `ui_cart_spec_t` (définie dans `ui_spec.h`),
 * qui décrit les menus, pages et paramètres disponibles.
 *
 * Ce module ne contient aucune logique I/O ni thread.
 * Il est manipulé uniquement par `ui_controller.c`.
 */

#ifndef BRICK_UI_UI_MODEL_H
#define BRICK_UI_UI_MODEL_H

#include <stdint.h>
#include <stdbool.h>
#include "ui_spec.h"

/* ============================================================
 * Constantes structurelles
 * ============================================================ */
#define UI_MAX_MENUS        8
#define UI_MAX_PAGES        5
#define UI_PARAMS_PER_PAGE  4

/* ============================================================
 * Structures de données
 * ============================================================ */

/**
 * @brief État d’un paramètre unique (valeur en RAM).
 */
typedef struct {
    uint8_t value;  /**< Valeur courante (copiée depuis default_value à l’initialisation). */
} ui_param_state_t;

/**
 * @brief État d’une page (jusqu’à 4 paramètres).
 */
typedef struct {
    ui_param_state_t params[UI_PARAMS_PER_PAGE];
} ui_page_state_t;

/**
 * @brief État d’un menu (jusqu’à 5 pages).
 */
typedef struct {
    ui_page_state_t pages[UI_MAX_PAGES];
} ui_menu_state_t;

/**
 * @brief État complet d’une cartouche (jusqu’à 8 menus).
 */
typedef struct {
    ui_menu_state_t menus[UI_MAX_MENUS];
} ui_cart_state_t;

/**
 * @brief Structure globale représentant l’état complet de l’UI.
 */
typedef struct {
    const ui_cart_spec_t *spec;  /**< Pointeur vers la spécification immuable de la cartouche. */
    ui_cart_state_t       vals;  /**< Valeurs courantes des paramètres (en RAM). */
    uint8_t               cur_menu; /**< Index du menu actif (0..7). */
    uint8_t               cur_page; /**< Index de la page active (0..4). */
    bool                  shift;    /**< État du bouton SHIFT (facultatif). */
} ui_state_t;

/* ============================================================
 * Fonctions
 * ============================================================ */

/**
 * @brief Initialise un état UI à partir d’une cartouche (`ui_cart_spec_t`).
 *
 * Copie les valeurs par défaut (`default_value`) de la spec vers la RAM.
 * Si un paramètre n’a pas de label, il est initialisé à 0.
 *
 * @param st   Pointeur vers la structure d’état à remplir.
 * @param spec Spécification de la cartouche (ou NULL pour effacer).
 */
void ui_state_init(ui_state_t *st, const ui_cart_spec_t *spec);

#endif /* BRICK_UI_UI_MODEL_H */
