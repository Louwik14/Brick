/**
 * @file ui_controller.c
 * @brief Logique centrale de l’UI Brick : gestion des menus, pages et encodeurs.
 *
 * @ingroup ui
 *
 * Responsibilities
 * - Maintenir l’état courant de l’UI (menu/page actifs)
 * - Appliquer les modifications utilisateur au modèle (valeurs UI)
 * - Propager les changements via l’interface `ui_backend` (abstraction cartouches)
 *
 * Threading & Timing
 * - Appelé uniquement depuis le thread UI (pas d’ISR)
 * - Toutes les fonctions sont non-bloquantes
 *
 * Contracts
 * - Ne modifie jamais le hardware directement
 * - `ui_switch_cart()` tolère NULL et réinitialise l’état proprement
 * - `ui_mark_dirty()` est appelé sur tout changement visible
 */

#include "ui_controller.h"
#include "ui_backend.h"
#include <string.h>

/* ============================================================
 * État global et dirty flag
 * ============================================================ */
static ui_state_t g_ui;
static volatile bool g_ui_dirty = true;

/* ============================================================
 * Gestion des cycles de menus (BM1..BM8)
 * ============================================================ */
typedef struct {
    const ui_menu_spec_t* opts[4]; /**< jusqu’à 4 options par bouton */
    uint8_t count;
    uint8_t idx;
} ui_cycle_t;

static ui_cycle_t s_cycles[8]; /**< un cycle par bouton BM1..BM8 */
static bool g_cycle_resume_mode = true; /**< true = reprendre dernier menu actif */

/* ============================================================
 * Fonctions utilitaires dirty flag
 * ============================================================ */
void ui_mark_dirty(void)   { g_ui_dirty = true;  }
bool ui_is_dirty(void)     { return g_ui_dirty;  }
void ui_clear_dirty(void)  { g_ui_dirty = false; }

/* ============================================================
 * Initialisation et changement de cartouche
 * ============================================================ */
void ui_init(const ui_cart_spec_t *spec) {
    memset(s_cycles, 0, sizeof(s_cycles));
    g_ui_dirty = true;

    if (!spec) {
        g_ui.spec = NULL;
        g_ui.cur_menu = 0;
        g_ui.cur_page = 0;
        return;
    }
    ui_state_init(&g_ui, spec);
}

void ui_switch_cart(const ui_cart_spec_t *spec) {
    g_ui_dirty = true;
    if (!spec) {
        g_ui.spec = NULL;
        g_ui.cur_menu = 0;
        g_ui.cur_page = 0;
        return;
    }
    ui_state_init(&g_ui, spec);
}

const ui_state_t*      ui_get_state(void)    { return &g_ui; }
const ui_cart_spec_t*  ui_get_cart(void)     { return g_ui.spec; }

/* ============================================================
 * Gestion des cycles de menus
 * ============================================================ */
void ui_cycles_set_options(int bm_index,
                           const ui_menu_spec_t* const* options,
                           uint8_t count) {
    if (bm_index < 0 || bm_index >= 8 || count == 0 || count > 4) return;
    s_cycles[bm_index].count = count;
    s_cycles[bm_index].idx   = 0;
    for (uint8_t i = 0; i < count; i++) {
        s_cycles[bm_index].opts[i] = options[i];
    }
}

void ui_cycles_advance(int bm_index) {
    if (bm_index < 0 || bm_index >= 8) return;
    if (s_cycles[bm_index].count > 0) {
        s_cycles[bm_index].idx = (s_cycles[bm_index].idx + 1) % s_cycles[bm_index].count;
        g_ui.cur_menu = (uint8_t)bm_index;
        g_ui.cur_page = 0;
        ui_mark_dirty();
    }
}

const ui_menu_spec_t* ui_resolve_menu(uint8_t bm_index) {
    if (bm_index < 8 && s_cycles[bm_index].count > 0) {
        return s_cycles[bm_index].opts[s_cycles[bm_index].idx];
    }
    if (!g_ui.spec) return NULL;
    return &g_ui.spec->menus[bm_index];
}

/* ============================================================
 * Gestion des boutons (menus & pages)
 * ============================================================ */
void ui_on_button_menu(int index) {
    if (index < 0 || index >= 8) return;

    if (s_cycles[index].count > 0) {
        if (g_ui.cur_menu == index) {
            /* 🔁 déjà sur ce bouton → avancer dans le cycle */
            ui_cycles_advance(index);
        } else {
            /* 🆕 nouveau bouton sélectionné */
            g_ui.cur_menu = (uint8_t)index;
            g_ui.cur_page = 0;
            if (!g_cycle_resume_mode) {
                s_cycles[index].idx = 0;
            }
            ui_mark_dirty();
        }
    } else {
        /* Sélection simple */
        g_ui.cur_menu = (uint8_t)index;
        g_ui.cur_page = 0;
        ui_mark_dirty();
    }
}

void ui_on_button_page(int index) {
    if (index < 0 || index >= 5) return;
    g_ui.cur_page = (uint8_t)index;
    ui_mark_dirty();
}

/* ============================================================
 * Gestion des encodeurs
 * ============================================================ */
static inline int clampi(int v, int mn, int mx) {
    if (v < mn) return mn;
    if (v > mx) return mx;
    return v;
}

void ui_on_encoder(int enc_index, int delta) {
    if (enc_index < 0 || enc_index >= 4) return;
    if (!g_ui.spec) return;

    const ui_menu_spec_t *menu = ui_resolve_menu(g_ui.cur_menu);
    if (!menu) return;
    const ui_page_spec_t *page = &menu->pages[g_ui.cur_page];

    const ui_param_spec_t *ps = &page->params[enc_index];
    ui_param_state_t *pv = &g_ui.vals
        .menus[g_ui.cur_menu].pages[g_ui.cur_page].params[enc_index];

    if (!ps->label) return; /* param absent */

    switch (ps->kind) {
    case UI_PARAM_CONT: {
        int step = (ps->meta.range.step > 0) ? ps->meta.range.step : 1;
        int v = (int)pv->value + delta * step;
        v = clampi(v, ps->meta.range.min, ps->meta.range.max);
        pv->value = (uint8_t)v;
        ui_backend_param_changed(ps->dest_id, (uint8_t)v,
                                 ps->is_bitwise, ps->bit_mask);
        ui_mark_dirty();
        break;
    }
    case UI_PARAM_ENUM: {
        int count = ps->meta.en.count;
        if (count <= 0) break;
        int v = (int)pv->value + delta;
        if (v < 0) v = 0;
        if (v >= count) v = count - 1;
        pv->value = (uint8_t)v;
        ui_backend_param_changed(ps->dest_id, (uint8_t)v,
                                 ps->is_bitwise, ps->bit_mask);
        ui_mark_dirty();
        break;
    }
    case UI_PARAM_BOOL: {
        if (delta == 0) break;

        /* cible : gauche (delta<0) => OFF(0), droite (delta>0) => ON(1) */
        uint8_t new_bit = (delta > 0) ? 1 : 0;

        if (ps->is_bitwise) {
            /* bitfield : set/clear le bit, sans toggle aveugle */
            uint8_t reg = ui_backend_shadow_get(ps->dest_id);
            if (new_bit) reg |=  ps->bit_mask;
            else         reg &= (uint8_t)~ps->bit_mask;

            ui_backend_shadow_set(ps->dest_id, reg);
            pv->value = (reg & ps->bit_mask) ? 1 : 0;
            ui_backend_param_changed(ps->dest_id, reg, true, ps->bit_mask);
        } else {
            pv->value = new_bit; /* 0 ou 1, clampé implicitement */
            ui_backend_param_changed(ps->dest_id, pv->value, false, 0);
        }

        ui_mark_dirty();
        break;
    }

    default:
        break;
    }
}

/* ============================================================
 * API publique : mode "cycle resume"
 * ============================================================ */
void ui_set_cycle_resume_mode(bool enable) {
    g_cycle_resume_mode = enable;
}

bool ui_get_cycle_resume_mode(void) {
    return g_cycle_resume_mode;
}
