/**
 * @file ui_backend.c
 * @brief Pont neutre entre UI et CartLink (shadow/param).
 * @ingroup ui
 */

#include "ui_backend.h"
#include "cart_link.h"       // cart_link_param_changed, cart_link_shadow_{get,set}
#include "cart_registry.h"   // cart_registry_get_active_id()

void ui_backend_param_changed(uint16_t id, uint8_t val, bool bitwise, uint8_t mask) {
    cart_link_param_changed(id, val, bitwise, mask);
}

uint8_t ui_backend_shadow_get(uint16_t id) {
    cart_id_t cid = cart_registry_get_active_id();   // <- ID (cid), pas un pointeur de spec
    return cart_link_shadow_get(cid, id);
}

void ui_backend_shadow_set(uint16_t id, uint8_t val) {
    cart_id_t cid = cart_registry_get_active_id();   // <- ID (cid)
    cart_link_shadow_set(cid, id, val);
}
